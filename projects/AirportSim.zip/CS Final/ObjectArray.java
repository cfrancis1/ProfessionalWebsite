package finalProject;

/*
 * Pairs Programming Christian Francis and Daniyal Khan
 * Object array same as used in previous lab assignments
 * has add, delete, getIndex etc methods
 * 
 * 
 */

public class ObjectArray {
	

	private final int MAX = 100;
	private Object[] objArray;
	private int index;   // (next empty slot)
	private int pointer;     //pointer variable
	private int counterAdd;

	//default constructor, instantiates objArray to MAX size and assigns 0 to index
	public ObjectArray(){
		objArray = new Object[MAX];
		index = 0;
		pointer = 0;
	}
	
	//nondefault constructor to instantiate an objArray to size, assigns 0 to index
	public ObjectArray(int size){
		objArray = new Object[size];
		index = 0;
		pointer = 0;
	}

	//return a copy of the objArray, accessor
	//Instantiate another objArray (new memory location) and copy the data into this 
	//new objArray, return this objArray
	public Object[] getobjArr(){
		Object[] objArrayCopy = new Object[MAX];
		for(int j = 0; j < getLength(); j++) {
			objArrayCopy[j] = objArray[j];
		}
		return objArrayCopy;
	}
	
	//method to return the entire array
	public Object[] getobjArray(){
		return objArray;
	}
	
	//return # of actual data in objArray, accessor
	public int getIndex(){
		return index;
	}
	
	//return an object at given pos
	public Object getObject(int uIndex){
		return objArray[uIndex];
	}
	
	//method to return the length of the array
	public int getLength(){
		return objArray.length;
	}
	
	//method to return the pointer position
	public int getPointer(){
		return pointer;
	}
	
	//method to set the index to what the user enters
	public void setIndex(int uIndex){
		index = uIndex;
	}
	
	//method to set the pointer to what the user enters
	public void setPointer(int uPointer){
		pointer = uPointer;
	}
	
	//return the string with contents of objArray
	public String toString(){
		String fullobjArray = "";
		for(int j = 0; j < index; j++){
			fullobjArray += (objArray[j].toString());
			System.out.println();
		}
		return fullobjArray;
	}
	
	//Method to print out one line of data from the array
	public String oneLine(int line){
		return objArray[line].toString();
	}
	
	//insert a new string into the next empty slot of the objArray if there is room, inc index
	public void add(Object testObj){
		if(getIndex()<getLength()){
			objArray[getIndex()] = testObj;
		}
		int newIndex = getIndex() + 1;
		setIndex(newIndex);
	}

	//searches the list for an object and returns the index where that object 
	//has been found or -1 if not found
	public int isThere(Object testObj){
		for(int index = 0; index < objArray.length; index++){
			if(objArray[index].equals(testObj)){
				return index;
			}
		}
		return -1;
	}

	//insert an object at particular index moving everything down
	public void insertObject(Object testObj, int insertPos){
		for(int i = getIndex() - 1; i > insertPos; i--){
			objArray[i+1] = objArray[i];
		}
		objArray[insertPos] = testObj;
		index++;
	}

	//replace an object with another object
	public void setObject(Object testObj, int insertPos){
		objArray[insertPos] = testObj;
		}
		
	//delete object from the specified position, check if list is empty
	public void delete (int delIndex){
		for(int i = delIndex; i < objArray.length - 1; i++){
			objArray[i] = objArray[i+1];
		}
		index--;
	}
	
	
	//deletes all data from list, returns index to 0
	public void clear(){
		for(int i = 0; i < getIndex(); i++){
			objArray[i] = null;
		}
		index = 0;
	}
	
	//automatically allocates more memory if needed
	public Object[] moreCapacity(){
		Object[] arrayTemp = new Object[getIndex()*2];
		for(int i = 0; i < getIndex(); i++){
			arrayTemp[i] = objArray[i];
		}
		return arrayTemp;
	}

	//remove excess capacity so that capacity matches size
	public Object[] trim(){
		Object[] arrayTemp = new Object[getIndex()];
		for(int i = 0; i < getIndex(); i++){
			arrayTemp[i] = objArray[i];
		}
		setIndex(arrayTemp.length-1);
		return arrayTemp;
	}
	
	//returns true if objArray is full, false if objArray is not
	public boolean isFull(){
		for(int i = 0; i < getIndex(); i++){
			if(objArray[i] == null){
				return false;
				}
			}
		return true;
	}
	
	//returns true if objArray is empty, false if objArray is not	
	
	public boolean isEmpty(){
		for(int i = 0; i < getIndex(); i++){
			if (objArray[i] != null){
				return false;
			}
		}
		return true;
	}
	
	//sets the iterator "pointer" to 0
	public void reset()	{
		setPointer(0);
	}
	
	//returns boolean if there is more data in the objArray
	public boolean hasNext(){
		if(getObject(pointer) == null){
			return false;
		}
		else{
			return true;
		}
	}
	
	//returns the object at the iterator "pointer", increments pointer
	public Object getNext(){
		setPointer(pointer+1);
		return getObject(pointer - 1);
	}
}
