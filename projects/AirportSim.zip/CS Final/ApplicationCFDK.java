package finalProject;

/*
 * Pairs Programming Christian Francis and Daniyal Khan
 * Calls interface to run the program
 * Other than that, not much happening in here
 * 
 * 
 */

import java.io.*;
import java.util.*;
import java.util.Scanner;

public class ApplicationCFDK{
	public static void main(String[] args) throws IOException{
		InterfaceCFDK.call(); //calls the menu
	}
}