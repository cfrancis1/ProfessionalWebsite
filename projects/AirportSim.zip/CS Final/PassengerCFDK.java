package finalProject;

/*
 * Pairs Programming Christian Francis and Daniyal Khan
 * this class is the assosciation relationship to FlightsCFDK
 * it is used to create instances of passengers in the flights class.
 * has the accessor and modifier methods for passenger attributes
 * 
 */

public class PassengerCFDK { 
	protected String name; //Instance variable for name
	protected String gender; //Instance variabel for gender
	protected String ssn; //Instance variable for ssn
	protected String dob; //Instance variable for dob
	
	public PassengerCFDK(){ //default constructor
		name = "";
		gender = "";
		ssn = "";
		dob = "";
	}
	
	public PassengerCFDK(String nameIn){ //Constructor the user uses when they search for someone
		setName(nameIn);
		gender = "";
		ssn = "";
		dob = "";
	}
	
	public PassengerCFDK(String nameIn, String genderIn, String ssnIn, String dobIn){ //Constructor with everything
		setName(nameIn);
		setGender(genderIn);
		setSsn(ssnIn);
		setDob(dobIn);
	}
	
	public String getSsn() { //method to get ssn
		return ssn;
	}
	
	public void setSsn(String ssnIn) { //method to set ssn
		ssn = ssnIn;
	}
	
	public String getDob() { //method to get dob
		return dob;
	}
	
	public void setDob(String dobIn) { //method tot set dob
		dob = dobIn;
	}
	
	public String getName() { //method to get name
		return name;
	}
	
	public void setName(String nameIn) { //method to set name
		name = nameIn;
	}
	
	public String getGender() { //method to get gender
		return gender;
	}
	
	public void setGender(String genderIn) { //method to set gender
		gender = genderIn;
	}
	
	public String toString() { //toString to print
		return String.format("%-35s%-20s%-25s%-35s", ("Name: " + name), (" Gender: " + gender), (" SSN: " + ssn), (" Date of Birth: " + dob));
	}
	
	
}
