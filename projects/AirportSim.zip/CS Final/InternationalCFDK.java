package finalProject;

/*
 * Pairs Programming Christian Francis and Daniyal Khan
 * Sub class of Flight which holds the data for the international flights
 * Most data are different forms of the constructor
 * The other data is the overridden method frequentFlyer which is changed from what it was in InternationalCFDK
 * The instance variable is what differences the international flights from the local ones as the international flights need a passport #
 */
 
public class InternationalCFDK extends FlightCFDK{
	protected String passportNo; //The passport # of the passenger
	
	public InternationalCFDK(){ //Default Constructor
		super();
		passportNo = "";
	}
	
	public InternationalCFDK(String nameIn){ //The Constructor that is used when the user creates the person they are searching for
		super(nameIn);
		passportNo = "";
	}
	
	public InternationalCFDK(PassengerCFDK passIn, String departingFromIn, String arrivingAtIn, String airlineIn, String flightNoIn, String durationIn, String passportNoIn){ //Constructor holding the Object from the has-a relationship
		super(passIn,departingFromIn,arrivingAtIn,airlineIn,flightNoIn,durationIn);
		passportNo = passportNoIn;
	}
	
	public InternationalCFDK(String nameIn, String genderIn, String ssnIn, String dobIn, String departingFromIn, String arrivingAtIn, String airlineIn, String flightNoIn, String durationIn){ //Constructor with all the data types excluding passport #
		super(nameIn,genderIn,ssnIn,dobIn,departingFromIn,arrivingAtIn,airlineIn,flightNoIn,durationIn);
		passportNo = "";
	}
	
	public InternationalCFDK(String nameIn, String genderIn, String ssnIn, String dobIn, String departingFromIn, String arrivingAtIn, String airlineIn, String flightNoIn, String durationIn, String passportNoIn){ //Constructor with all the data types including passport #
		super(nameIn,genderIn,ssnIn,dobIn,departingFromIn,arrivingAtIn,airlineIn,flightNoIn,durationIn);
		passportNo = passportNoIn;
	}

	public String getPassportNo(){ //returns passport number
		return passportNo;
	}
	
	public void setPassportNo(String passportIn) { //sets passport number		
		passportNo = passportIn;
	}
	
	public String toString() { //toString to print in a clean format 
		return String.format("%-35s%-20s%-25s%-35s%-40s%-40s%-35s%-35s%-25s%-25s\n", ("Name: " + pass.getName()), (" Gender: " + pass.getGender()), (" SSN: " + pass.getSsn()), (" Date of Birth: " + pass.getDob()), (" Departing From: " + departingFrom), (" Arriving At: " + arrivingAt), (" Airline: " + airline), (" Flight Number: " + flightNo), (" Duration: " + duration), (" Passport Number: " + passportNo));
	
	}
	
	@Override
	public String frequentFlyer() { //Overridden method which calculates the amount of Frequent Flyer points the international flyer has based on how long they flew
		String duration = getDuration();
		int hours = Integer.parseInt(duration.substring(0,2)); //Gets the hours from the object and turns them into an int
		int minutes = Integer.parseInt(duration.substring(4,6)); //Gets the mins from the object and turns them into an int
		
		int points = ((hours * 60) + minutes) * 2; //Calculates the amound of points someone recieves for flying *2 for flying internationally
		
		return "Frequent flyer points for international passenger " + getName() +  " (including bonus) are  = " + points; //Prints out their point total
		
	}
}