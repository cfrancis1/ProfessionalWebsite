package finalProject;

/*
 * Pairs Programming Christian Francis and Daniyal Khan
 * Main class
 * Has the constructors, and the accessors and modifiers for all parameters of flights 
 * Has the compare to method to order objects by name
 * 
 */

public abstract class FlightCFDK implements Comparable {
	protected String flightNo; // Instance variable for the Flight number
	protected String airline; // Instance Variable for the airline
	protected String arrivingAt; // Instance Variable for the arrival location
	protected String departingFrom; // Instance variable for the departing location
	protected String duration; // Instance variable for the duration
	protected PassengerCFDK pass; //Instance variable for the passenger object

	public FlightCFDK() { //Default constructor
		flightNo = "xxxx";
		arrivingAt = "";
		departingFrom = "";
		duration = "";
		airline = "";
		pass = new PassengerCFDK();
	}
	
	public FlightCFDK(String nameIn){ //Constructor the user uses when they search for someone
		flightNo = "xxxx";
		arrivingAt = "";
		departingFrom = "";
		duration = "";
		airline = "";
		pass = new PassengerCFDK(nameIn);
	}
	
	public FlightCFDK(String departingFromIn, String arrivingAtIn, String airlineIn, String flightNoIn, String durationIn) { //Constructor for all the variables except the passenger
		setFlightNo(flightNoIn);
		setArrivingAt(arrivingAtIn);
		setDepartingFrom(departingFromIn);
		setDuration(durationIn);
		setAirline(airlineIn);
		pass = new PassengerCFDK();
	}
	
	public FlightCFDK(PassengerCFDK passengerIn, String departingFromIn, String arrivingAtIn, String airlineIn, String flightNoIn, String durationIn) { //Constructor for everything including the passenger
		setFlightNo(flightNoIn);
		setArrivingAt(arrivingAtIn);
		setDepartingFrom(departingFromIn);
		setDuration(durationIn);
		setAirline(airlineIn);
		pass = passengerIn;
	}
	
	public FlightCFDK(String nameIn, String genderIn, String ssnIn, String dobIn, String departingFromIn, String arrivingAtIn, String airlineIn, String flightNoIn, String durationIn) { //Constructor for everything
		setFlightNo(flightNoIn);
		setArrivingAt(arrivingAtIn);
		setDepartingFrom(departingFromIn);
		setDuration(durationIn);
		setAirline(airlineIn);
		pass = new PassengerCFDK(nameIn, genderIn, ssnIn, dobIn);
	}
	
	public String getAirline() { //method to return airline
		return airline;
	}
	
	public void setAirline(String airlineIn) { //method to set airline
		airline = airlineIn;
	}
	
	public String getFlightNo() {//method to get flight number
		return flightNo;
	}
	
	public void setFlightNo(String flightNoIn) { //method to set flight number
		flightNo = flightNoIn;
	}
	
	public String getArrivingAt() { //method to get arrival location
		return arrivingAt;
	}
	
	public void setArrivingAt(String arrivingAtIn) { //method to set arrival location
		arrivingAt = arrivingAtIn;
	}
	
	public String getDepartingFrom() { //method to get departing location
		return departingFrom;
	}
	
	public void setDepartingFrom(String departingFromIn) { //method to set departing location
		departingFrom = departingFromIn;
	}
	
	public String getDuration() { //method to get duration
		return duration;
	}
	
	public void setDuration(String durationIn) { //method to set duration
		duration = durationIn;
	}
	
	public String getSsn() { //method to get ssn
		return pass.ssn;
	}
	
	public void setSsn(String ssnIn) { //method to set ssn
		pass.ssn = ssnIn;
	}
	
	public String getDob() { //method to get dob
		return pass.dob;
	}
	
	public void setDob(String dobIn) { //method to set dob
		pass.dob = dobIn;
	}
	
	public String getName() { //method to get name
		return pass.name;
	}
	
	public void setName(String nameIn) { //method to set name
		pass.name = nameIn;
	}
	
	public String getGender() { //method to get gender
		return pass.gender;
	}
	
	public void setGender(String genderIn) { //method to set gender
		pass.gender = genderIn;
	}
	
	public PassengerCFDK getPassenger(){ //method to get passenger
		return pass;
	}
	
	public void setPassenger(PassengerCFDK passIn){ //method to set passenger
		pass = passIn;
	}
	
	public abstract String frequentFlyer(); //custom overridden method
	
	public int compareTo(Object flight){ //compare to which compares opbjects based on name
		FlightCFDK f = (FlightCFDK)flight;
		String s = pass.getName();
		
		if(s.compareTo(f.getName()) > 0)
			return 1;
		else if (s.compareTo(f.getName()) < 0)
			return -1;
		else
			return 0;
	}	
}
