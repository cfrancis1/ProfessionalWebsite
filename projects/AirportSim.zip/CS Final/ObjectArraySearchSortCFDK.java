package finalProject;

/*
 * Pairs Programming Christian Francis and Daniyal Khan
 * Subclass class as previous labs but with added objects
 * Objects include Sequential Search, Binary Search and Selection Sort
 * 
 * 
 */

public class ObjectArraySearchSortCFDK extends ObjectArray {
	
	public ObjectArraySearchSortCFDK(){ //Default constructor
		super();
	}
	
	public ObjectArraySearchSortCFDK(int size){ //NonDefault constructor
		super(size);
	}
	
	public int sequentialSearch(FlightCFDK searchkey){ //Searches by looking at every object in the array
		FlightCFDK temp1; //temp FlightCFDK object
		for(int i=0; i<getIndex(); i++){
			temp1 = (FlightCFDK)getObject(i);
			if(searchkey.getName().equals(temp1.getName())){ //Checks if object author and title is equal to the object youre searching for
				return i; //returns position of the correct object in the array
			}
		}
		return -1; //returns -1 if object is not found
	}
	
	public int binarySearch(FlightCFDK searchkey){ //Searches by dividing the array into sections and looking if the object is in the middle
		int low = 0;
		int high = getIndex();
		int middle;
		while(high>=low) //Loop to get through the array
		{
			middle = (low + high) / 2; //divides the array in half
			FlightCFDK temp2 = (FlightCFDK)getObject(middle);
			if(searchkey.getSsn().equals(temp2.getSsn())) { //checks if the author youre looking for is the author of the object
				return middle; //returns position of the correct object in the array
			}
			else if(searchkey.compareTo(temp2) < 0){ //uses compareTo() to  check how obj1 relates to obj2
				high =  middle - 1;
			}
			else if(searchkey.compareTo(temp2) > 0){ //uses compareTo() to  check how obj1 relates to obj2
				low = middle + 1;
			}	
		}
		return -1; //returns -1 if object is not found
	}
	

	public void selectionSort(){
		FlightCFDK temp3, temp4;
		int compareFlight, passCount, flight1;
		int last = getIndex();
		for(passCount = 0; passCount < last-1; passCount++){ //Loop to go through the list
			flight1 = passCount;
			for(compareFlight = passCount + 1; compareFlight < last; compareFlight++){ // Loop to get the card being compared
				FlightCFDK flightA = (FlightCFDK)getObject(compareFlight);
				FlightCFDK flightB = (FlightCFDK)getObject(passCount);
				if(flightA.compareTo(flightB)<0){ //uses compareTo() to  check how obj1 relates to obj2
					flight1 = compareFlight; // Following lines swap the objects positions based on the names of the authors
					temp3 = (FlightCFDK)getObject(flight1);
					temp4 = (FlightCFDK)getObject(passCount);
					setObject(temp4, flight1);
					setObject(temp3, passCount);
				}
			}
		}
	}
}