package finalProject;

/*
 * Pairs Programming Christian Francis and Daniyal Khan
 * Sub class of Flight which holds the data for the local flights
 * Most data are different forms of the constructor
 * The other data is the overridden method frequentFlyer which is changed from what it was in InternationalCFDK
 * 
 */
 
public class LocalCFDK extends FlightCFDK{

	public LocalCFDK(){ //Default constructor
		super();
	}
	
	public LocalCFDK(String nameIn){ //The Constructor that is used when the user creates the person they are searching for
		super(nameIn);
	}
	
	public LocalCFDK(PassengerCFDK passIn, String departingFromIn, String arrivingAtIn, String airlineIn, String flightNoIn, String durationIn){ //Constructor holding the Object from the has-a relationship
		super(passIn,departingFromIn,arrivingAtIn,airlineIn,flightNoIn,durationIn);
	}
	
	public LocalCFDK(String nameIn, String genderIn, String ssnIn, String dobIn, String departingFromIn, String arrivingAtIn, String airlineIn, String flightNoIn, String durationIn){ //Constructor with all the data types
		super(nameIn,genderIn,ssnIn,dobIn,departingFromIn,arrivingAtIn,airlineIn,flightNoIn,durationIn);
	}
	
	public String toString() { //toString to print in a clean format
		return String.format("%-35s%-20s%-25s%-35s%-40s%-40s%-35s%-35s%-25s\n", ("Name: " + pass.getName()), (" Gender: " + pass.getGender()), (" SSN: " + pass.getSsn()), (" Date of Birth: " + pass.getDob()), (" Departing From: " + departingFrom), (" Arriving At: " + arrivingAt), (" Airline: " + airline), (" Flight Number: " + flightNo), (" Duration: " + duration));
	
	}
	
	@Override
	public String frequentFlyer() { //Overridden method which calculates the amount of Frequent Flyer points the domestic flyer has based on how long they flew
		String duration = getDuration();
		int hours = Integer.parseInt(duration.substring(0,2)); //Gets the hours from the object and turns them into an int
		int minutes = Integer.parseInt(duration.substring(4,6)); //Gets the mins from the object and turns them into an int
		
		int points = (hours * 60) + minutes; //Calculates the amound of points someone recieves for flying
		
		return "Frequent flyer points for domestic passenger " + getName() +  " are = " + points; //Prints out their point total
		
	}
}