package finalProject;

/*
 * Pairs Programming Christian Francis and Daniyal Khan
 * The main program runs in this class
 * Imports all passengers from text file
 * shows up a menu for user to pick what to do next
 * gives 6 options 
 * calls on methods from object class to search, sort, create, delete objects in flight array
 * creates a text file to display array and the frequent flyer points
 */

import java.io.*;
import java.util.*;

public class InterfaceCFDK{
	
	public static void call(){ //runs the entire program
		boolean running = true;
		boolean gettingAnswer = true;
		int tally = 0;
		Scanner scan = new Scanner(System.in);
		ObjectArraySearchSortCFDK flightArray = new ObjectArraySearchSortCFDK();
		FileInputStream iFile = null;
		try{
			iFile = new FileInputStream("PassengerDataCFDK.txt"); 
			}
		catch(FileNotFoundException e) {
			System.err.println("Wrong file name");
			return;
		}
		Scanner scanTxt = new Scanner(iFile); //scanner for .txt file
		int userInput = 0;
		while(scanTxt.hasNextLine()){
			String s = scanTxt.nextLine();
			String[] people = s.split(",");
			if(people.length == 9){ //assigns to local passenger
				PassengerCFDK localP = new PassengerCFDK (people[0], people[1], people[2], people[3]);
				LocalCFDK local = new LocalCFDK (localP, people[4], people[5], people[6], people[7], people[8]);
				if(flightArray.isFull() == true){
					flightArray.moreCapacity();
				}
				flightArray.add(local);	
			}
			if(people.length == 10){ //assigns to international passenger
				PassengerCFDK localP = new PassengerCFDK (people[0], people[1], people[2], people[3]);
				InternationalCFDK international = new InternationalCFDK (localP, people[4], people[5], people[6], people[7], people[8], people[9]);
				if(flightArray.isFull() == true){
					flightArray.moreCapacity();
				}
				flightArray.add(international);					
			}		
		}
		
		System.out.println("Welcome to the O'Hare airport data collection terminal.");
		while(running){ //loop keeps running till user chooses to exit
			userInput = userMenuChoice();
		
			if(userInput == 1){
				gettingAnswer = personSearch(flightArray);
			}
			else if(userInput == 2){
				gettingAnswer = addPerson(flightArray);
			}
			else if(userInput == 3){
				gettingAnswer = deletePerson(flightArray);
			}
			else if(userInput == 4){
				gettingAnswer = sortArray(flightArray);
			}
			else if(userInput == 5){
				gettingAnswer = printArray(flightArray);
			}
			else if(userInput == 6){
				output(flightArray);
				exitProgram();
			}
		}
	}
	
	public static int userMenuChoice(){ //checks users choice and makes sure it is within the choice range
		Scanner scan = new Scanner(System.in);
		boolean gettingAnswer = true;
		int tally = 0;
		int userInput = 0;
		while(gettingAnswer){
			System.out.println("Please enter the number of what you would like to do: ");
			System.out.println("1. Search for a passenger in the data set.\n2. Add a passenger to the data set.\n3. Delete a pre-existing passenger from the data set.\n4. Sort the passengers in the 	data set (by name).\n5. Print out all the passengers.\n6. Exit the program.");
			if(scan.hasNextInt()){
				userInput=scan.nextInt();
				if(userInput == 1 || userInput == 2 || userInput == 3 || userInput == 4 || userInput == 5 || userInput == 6){
					gettingAnswer = false;
					tally = 1;
					return userInput;
				}
				else if(userInput < 1 || userInput > 6){
					tally = 0;
					System.out.println("That integer is not in range, please try again.");
					gettingAnswer = true;
				}
			}
			else if(tally == 1){
				tally = 0;
				scan.nextLine();
				scan.nextLine();
				System.out.println("This is not an integer, please try again.");
				gettingAnswer = true;
			}
			else{
				tally = 0;
				scan.nextLine();
				System.out.println("This is not an integer, please try again.");
				gettingAnswer = true;
			}
		}
		return -1;
	}
	
	public static boolean personSearch(ObjectArraySearchSortCFDK flightArray){ //method to search passengers
		String userSearch = "";
		Scanner scan = new Scanner(System.in);
		System.out.print("Please enter the First and Last name of the person you would like to search for (seperated by a space and with proper casing): ");
		userSearch = scan.nextLine();
		LocalCFDK search = new LocalCFDK(userSearch);
		int searchResult = flightArray.sequentialSearch(search);
		if(searchResult == -1){
			System.out.println("The person you were searching for does not exist. Please try again.\n");
			return true;
		}
		else{
			System.out.println("\nThe person you were searching for is in the array at index " + searchResult + ", and here is their data:\n" + flightArray.oneLine(searchResult) + "\n");
		}
		return true;
	}
	
	public static boolean addPerson(ObjectArraySearchSortCFDK flightArray){ //method to add passenger to the flight array list
		boolean correctFormat = false;
		String userTime = "";
		Scanner scan = new Scanner(System.in);
		String userFlightType = "";
		int i;
		if(flightArray.isFull() == true){
			flightArray.moreCapacity();
		}
		System.out.print("Would you like to enter in an International or Local flyer? ");
		userFlightType = scan.next().toLowerCase();
		
		if(userFlightType.equals("local")){ //creates a local passenger, takes all details from user
			System.out.print("Please enter their name: ");
			scan.nextLine();
			String userName = scan.nextLine();
			System.out.print("Please enter their gender (M/F/O): ");
			String userGender = scan.nextLine();
			System.out.print("Please enter their Social Security Number for your person: ");
			String userSSN = scan.nextLine();
			System.out.print("Please enter their Date of Birth (MM/DD/YYYY): ");
			String userYear = scan.nextLine();
			System.out.print("Please enter their Departing airport: ");
			String userDeparting = scan.nextLine();
			System.out.print("Please enter their Arriving Airport: ");
			String userArriving = scan.nextLine();
			System.out.print("Please enter their Airline: ");
			String userAirline = scan.nextLine();
			System.out.print("Please enter their Flight Number: ");
			String userFlightNo = scan.nextLine();
			while(correctFormat == false){ //makes sure format is right
				System.out.print("Please enter their Travel Time (Required: HHh MMm format): ");
				userTime = scan.nextLine();
				try{
					int tempHours = Integer.parseInt(userTime.substring(0,2)); //Gets the hours from the object and turns them into an int
					int tempMinutes = Integer.parseInt(userTime.substring(4,6)); //Gets the mins from the object and turns them into an int
					correctFormat = true;
				}
				catch(StringIndexOutOfBoundsException nfe){
					System.out.println("That is not the correct format, please try again");
					correctFormat = false;
				}
			}
			LocalCFDK userObjectL = new LocalCFDK (userName, userGender, userSSN, userYear, userDeparting, userArriving, userAirline, userFlightNo, userTime);
			flightArray.add(userObjectL);
			System.out.println("\nHere is the data of the person you added:\n" + flightArray.oneLine(flightArray.getIndex()-1));
			System.out.println();
		}
		else if(userFlightType.equals("international")){ //creates an international passenger, takes all details from user
			System.out.print("Please enter their name: ");
			scan.nextLine();
			String userName = scan.nextLine();
			System.out.print("Please enter their gender (M/F/O): ");
			String userGender = scan.nextLine();
			System.out.print("Please enter their Social Security Number for your person: ");
			String userSSN = scan.nextLine();
			System.out.print("Please enter their Date of Birth (MM/DD/YYYY): ");
			String userYear = scan.nextLine();
			System.out.print("Please enter their Departing airport: ");
			String userDeparting = scan.nextLine();
			System.out.print("Please enter their Arriving Airport: ");
			String userArriving = scan.nextLine();
			System.out.print("Please enter their Airline: ");
			String userAirline = scan.nextLine();
			System.out.print("Please enter their Flight Number: ");
			String userFlightNo = scan.nextLine();
			while(correctFormat == false){ // makes sure format is right
				System.out.print("Please enter their Travel Time (Required: HHh MMm format): ");
				userTime = scan.nextLine();
				try{
					int tempHours = Integer.parseInt(userTime.substring(0,2)); //Gets the hours from the object and turns them into an int
					int tempMinutes = Integer.parseInt(userTime.substring(4,6)); //Gets the mins from the object and turns them into an int
					correctFormat = true;
				}
				catch(StringIndexOutOfBoundsException nfe){
					System.out.println("That is not the correct format, please try again");
					correctFormat = false;
				}
			}
			System.out.print("Please enter their 9 digit Passport Number: ");
			String userPass = scan.nextLine();
			InternationalCFDK userObjectI = new InternationalCFDK (userName, userGender, userSSN, userYear, userDeparting, userArriving, userAirline, userFlightNo, userTime, userPass);
			flightArray.add(userObjectI);
			System.out.println("\nHere is the data of the person you added:\n" + flightArray.oneLine(flightArray.getIndex()-1));
			System.out.println();
		}
		else{
			System.out.println("Neither of those were options, please try again.");
			return true;
		}
		return true;
	}
	
	public static boolean deletePerson(ObjectArraySearchSortCFDK flightArray){ //method to delete a passenger from the flight array
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the index of person who's data you would like to delete: ");
		if(scan.hasNextInt()){
			int response = scan.nextInt();
			if(response > flightArray.getLength() || response < 0){
				System.out.println("Entered index does not exist, please try again.");
			}
			else{
				flightArray.delete(response);
				System.out.println("The data for the person at index " + response + " has been deleted.");
			}
		}
		return true;
	}
	
	public static boolean sortArray(ObjectArraySearchSortCFDK flightArray){ //method that sorts passengers by name
		flightArray.selectionSort();
		System.out.println("The data has been sorted\n");
		return true;
	}
	
	public static boolean printArray(ObjectArraySearchSortCFDK flightArray){ //method to print out all passengers 
		Scanner scan = new Scanner(System.in);
		System.out.print("Would you also like to see the passengers Frequent Flyer points? (Y/N) ");
		if(scan.hasNext()){
			String answer = scan.nextLine().toLowerCase();
			if(answer.equals("y")){
				for(int i = 0; i < flightArray.getIndex(); i++){
					FlightCFDK temp = (FlightCFDK)flightArray.getObject(i);
					System.out.println(temp.frequentFlyer());
				}
			}
		}
		System.out.print(flightArray.toString());
		return true;
	}
	
	public static void exitProgram(){ //method to exit out of the program
		System.out.println("Thank you for partaking in our program.");
		System.exit(0);
	}
	
	public static void output(ObjectArraySearchSortCFDK flightArray){ //method to print out all info to a text file
		FileOutputStream fileOutput = null;
		try{
			fileOutput = new FileOutputStream("MenuOutputCFDK.txt");
		} 
		catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		PrintWriter pw = new PrintWriter(fileOutput);
		
		for(int i = 0; i < flightArray.getIndex(); i++){
			pw.format("" + flightArray.getNext() + "%n");
		}
		pw.println();
		for(int i = 0; i < flightArray.getIndex(); i++){
			FlightCFDK temp = (FlightCFDK)flightArray.getObject(i);
			pw.format("" + temp.frequentFlyer() + "%n");
		}
		
		pw.flush();
		pw.close();
	}
}