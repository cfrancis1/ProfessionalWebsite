#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	char data[50] = "";
	char *remove_chars;
	size_t remove_length;
	int del_node;
	int i;
	int j;	
	if (argc < 3) {
		printf("Usage: %s STRING1 STRING2\n", argv[0]);
		printf("       %s -d STRING\n", argv[0]);
		exit(1);
	} else if (strcmp(argv[1], "-d") == 0) {
		
		while(1){
                        int c = fgetc(stdin);
                        if (c == EOF)
                                break;
                        for (j = 0; j < strlen(argv[2]); j++) {
				i = 0;
                                if (c == argv[2][j]) {
                                        i = 1;
                                        break;
                                }
                        }
			if(i == 0)
                        	fputc(c, stdout);
                }
                //fputc('\n', stdout);
                exit(0);
	} else if (strlen(argv[1]) != strlen(argv[2])){
                printf("STRING1 and STRING2 must have the same length\n");
                exit(1);
        } else {
		while(1){
			int c = fgetc(stdin);
			if (c == EOF)
                        	break;
			for (j = 0; j < strlen(argv[1]); j++) {
				if (c == argv[1][j]) {
					c = argv[2][j];
					break;
				}
			}
			fputc(c, stdout);
		}
		//fputc('\n', stdout);
		exit(0);	
	}
	return 0;
}
