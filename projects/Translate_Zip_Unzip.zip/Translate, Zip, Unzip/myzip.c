#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
	FILE *fp = fopen(argv[1], "r");
	char nextChar = ' ', currChar = ' ';
	int counter = 0;
	if (argc < 2) {
		printf("Usage: %s FILENAME\n", argv[0]);
		exit(1);
	} else {
		currChar = fgetc(fp);
		counter += 1;
		while(1) {
			nextChar = fgetc(fp);
			if(currChar == nextChar) {
				counter +=1;
			} else {
				if(nextChar == EOF) {     
                                	fwrite(&counter, 4, 1, stdout);
                                	fwrite(&currChar, 1, 1, stdout);
					break;
				} else {
					fwrite(&counter, 4, 1, stdout);
					fwrite(&currChar, 1, 1, stdout);
					counter = 1;
					currChar = nextChar;
				}
			}
		}
		fclose(fp);
		exit(0);
	}
	return 0;
}
